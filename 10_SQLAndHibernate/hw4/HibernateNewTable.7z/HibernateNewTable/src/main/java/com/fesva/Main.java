package com.fesva;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Loader ld=new Loader();
        ld.main("");


    }
}
